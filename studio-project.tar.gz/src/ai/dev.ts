import { config } from 'dotenv';
config();

import '@/ai/flows/ai-customize-resume-content.ts';