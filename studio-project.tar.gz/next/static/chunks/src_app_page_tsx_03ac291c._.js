(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_cbb7d4b9._.js",
  "static/chunks/node_modules_cefee1bc._.js"
],
    source: "dynamic"
});
