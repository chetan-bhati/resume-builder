(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_64c3a01e._.js",
  "static/chunks/node_modules_5c2faea9._.js"
],
    source: "dynamic"
});
